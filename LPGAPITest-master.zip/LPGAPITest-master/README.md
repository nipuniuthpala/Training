# LPG API Test

I have done the API Test using Restassured Framework and Java language using cucumber plugin for feature files.

Download the git Repo and open in Intellij Idea or in Eclips

You need to install the Cucumber plugin.

Download all the dependencies in pom.xml. It will automatically download the dependencies.

Run the TestSiteRunner class in the src/test folder.

![title](https://github.com/nipuniuthpala/images/blob/master/Screenshot%202021-04-18%20at%2008.06.33.png)

You can see the  Test reports generated under target/ cucumber-reports  

index.html will give you the Passed steps in the feature file.


![title](https://github.com/nipuniuthpala/images/blob/master/Screenshot%202021-04-18%20at%2008.05.52.png)
