package common;

public class Constants {
    public static final String USER_URL="https://reqres.in/api/users/";

    public static final String users_URL="https://reqres.in/api/users?page=";

    public static final String pathToResources=System.getProperty("user.dir")+"/src/main/java/data/";
}