package utilities;

public class Logger {

    public static void Log(Object obj){
        System.out.println(obj);
    }
}
