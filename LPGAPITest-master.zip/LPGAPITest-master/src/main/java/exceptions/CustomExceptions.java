package exceptions;

public class CustomExceptions  extends RuntimeException {

    public CustomExceptions(String msg) {
        super(msg);
    }
}
